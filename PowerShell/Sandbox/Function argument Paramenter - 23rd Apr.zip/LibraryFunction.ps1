﻿

Function addOne($intIN) 
{ 
    $intIN + 1 
} 
Function addTwo($intIN) 
{ 
    $intIN + 2 
}
