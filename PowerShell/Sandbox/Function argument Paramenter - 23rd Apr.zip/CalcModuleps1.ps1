﻿
function add-numbers($a, $b){

    
    $c = $a+ $b 
    Write-Host $c 
}