﻿
. "C:\Users\vkumar15\Documents\Training\Training\1. PowerShell\PowerShell\Sandbox\LibraryFunction.ps1" 

addone -intIn 10
addTwo -intIn 11
